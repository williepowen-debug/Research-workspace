# Closeout delivery B and lifecycle reconciliation

Authority: Will's “Can we fix these issues?” following the saved October19 blocker investigation authorizes this bounded maintenance pass and brings delivery B forward. Existing B design/acceptance is `PROME/proposals/2026-10-14_closeout-display-verification-PROPOSAL.md` §B; WQ430 supplies its additional result read. Deck A remains paused, Helm retired; WQ448 push enforcement is not installed by this work.

Delivery episode reads: 3 (existing plan history); additional result reads: 0 (one authorized by WQ430). Lifecycle reconciliation reads: 0 (new reconciliation defect, not the earlier enumeration implementation).

## Conditions written before implementation

Delivery B1–B8 remain binding. Implement an explicit versioned contract, retaining legacy strict verification. Full Git inventory includes excluded paths, committed plus pending work and deletions. Each observed-only classification binds an exact captured version, a named owner, attributable evidence and a reason it supports no delivered claim. Classification is a recorded human judgment reviewed at freeze, not inferred from directory or commit subject. New unrelated versions may be explicitly classified without changing the review contract; missing/ambiguous classifications block. This does not authenticate the truth of an operator's attribution.

The contract freezes baseline, anchor, delivered bytes and earlier commit versions, plus reproducible evidence versions and dependent claims (historical/current). Hash changes or role changes invalidate review. Promotion, gate and named-commit checks share verification. A caller's path list cannot hide actual commit changes. A separate snapshot comparison checks a later outgoing/fresh-fetch commit without claiming all its content reviewed; ancestry alone is insufficient. Legacy consumed-move and receipt exclusions remain unchanged. No automatic migration of the live legacy receipt.

Neighbours: ordinary unrelated pending packet; overlap committed+pending and delivered+evidence; wrong owner includes foreign files inside PROME and PROME nested inbox additions; missing baseline/schema/provenance/dependency/empty list; concurrency includes observed churn, changed current evidence, moving HEAD and later carried commits. Tests use disposable repositories, with ResourceWarning as error.

Lifecycle: a later event may resolve only an explicitly named original touch key with matching desk, owner and session identity, supported timestamps and evidence. Append-only source rows remain unchanged. A bad link/correction fails visibly; a different session at the same desk never closes it. Terminal receipts cannot erase a later working event. Unstructured historical identity cannot be invented. A current-session inventory must identify its session, expected original keys and evidence of runtime enumeration; its result is separate from historical unresolved debt. The ordinary gate does not fabricate a complete inventory. Missing inventory stays UNKNOWN. Ordinary/overlap/wrong-owner/missing/concurrent cases all apply; real working sessions remain working.

## Disposition

IMPLEMENTED: pending. TESTED: pending. INDEPENDENTLY VERIFIED: pending. STILL UNRESOLVED: full-fleet native discovery and historical missing evidence are not created by a ledger reader. Live WALTER pagination and WQ458 renewal remain separate.
